/*****************************************************************************/
/*        Copyright (C) 2005  NORMAN MEGILL  nm at alum.mit.edu              */
/*            License terms:  GNU General Public License                     */
/*****************************************************************************/
/*34567890123456 (79-character line to adjust editor window) 2345678901234567*/

/******************************************************************************
 *
 *  This is a collection of useful functions
 *
 ******************************************************************************/

/* (This file is currently empty.) */
/* The include makes file non-empty for ANSI compliance. */
#include <stdio.h>
